.. BZRFlag documentation master file, created by
   sphinx-quickstart on Tue Nov 24 12:15:53 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

BZFlag With Robots!
===================================

Contents:

.. toctree:: 
   :maxdepth: 2

   game.rst
   world.rst
   server.rst
   headless.rst
   graphics.rst
   modpygame.rst
   collide.rst

Other
==================

* :ref:`search`

