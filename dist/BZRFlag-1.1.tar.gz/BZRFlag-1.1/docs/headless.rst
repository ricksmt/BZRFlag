Headless - For headless servers
===============================

.. toctree::
   :maxdepth: 2

.. module:: headless

Display
-------
.. autoclass:: Display
   :members:
   :undoc-members:

Input
-------
.. autoclass:: Input
   :members:
   :undoc-members:
