collide.py - collision library
==============================

.. toctree::
   :maxdepth: 3

.. automodule:: collide
   :members:
   :undoc-members:
   :inherited-members:
